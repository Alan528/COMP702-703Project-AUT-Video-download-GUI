#List of Libraries for supporting the program GUI
from importlib.resources import path
from tkinter import *
import webbrowser
from tkinter.ttk import Progressbar
import time as tm
